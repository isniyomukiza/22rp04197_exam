<?php 
include("con.php");
?>
<?php 

session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="POST">
    Username:<br> <input type="text" name="username" id=""><br>
    Password: <br><input type="password" name="password" id=""><br>
<input type="submit" name="submit" value="Login">
</form>    
<?php 
if(isset($_POST['submit']))
{
    $username=trim($_POST['username']);
    $password=trim($_POST['password']);
    $select=mysqli_query($con,'SELECT *FROM users');
    if(mysqli_num_rows($select)> 0)
    {
        $row=mysqli_fetch_array($select);
        if($rows=1){
            $_COOKIE['username']=$username;
         
        $_SESSION['username']=$username;
        $_SESSION['password']=$password;
        echo"<script>alert('Welcome');window.location='indx.php';</script>";
        }
}}
?>
</body>
</html>