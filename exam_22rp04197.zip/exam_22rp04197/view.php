<?php 
include("con.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<a href="view.php">View Employees</a>
<a href="insert.php">Record Employees</a>
    <h2>LIST OF ALL EMPLOYEES</h2>
    <table border="1">
        <th>EMPLOYEE_NAMES</th><TH>EMAIL</TH><TH>PHONE</TH><TH>POSITION</TH><TH>ADDRESS</TH><th>CREATED_AT</th><th colspan="2">ACTION</th>
    
        <?php 
        $select=mysqli_query($con,"SELECT*FROM employees");
        while ($rows=mysqli_fetch_array($select))
        {
            $id=$rows["id"];
            echo"<tr><td>".$rows['employee_name']."</td><td>"
            .$rows["email"]."</td><td>".$rows['phone'].
            "</td><td>".$rows['position']."</td><td>".$rows['address'].
            "</td><td>".$rows['created_at']."</td>";
            echo"<td> <a href='delete.php?id=".$rows['id']."'> Delete</a>";
            echo"<td> <a href='update.php?id=".$rows['id']."'> Update</a>";
            "</tr>";
        }
        ?>
    </table>
</body>
</html>