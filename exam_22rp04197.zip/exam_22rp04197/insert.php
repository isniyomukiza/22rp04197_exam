<?php 
include("con.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<a href="view.php">View Employees</a>
<a href="insert.php">Record Employees</a>
    <h2>EMPLOYEE REGISTRATION FORM</h2>
<form action="" method="POST">
    Employee_name:<br> <input type="text" name="employee_name" id="" required><br>
    Email: <br><input type="email" name="email" id="" required><br>
    Phone:<br> <input type="number" name="phone" id="" required><br>
    Position: <br><input type="text" name="position" id="" required><br>
  Address:<br> <input type="text" name="address" id="" required><br>
<input type="submit" name="submit" value="Add Employee">
</form>   
<?php 
if(isset($_POST["submit"]))
{
    $name=trim($_POST['employee_name']);
    $email=trim($_POST['email']);
    $phone=trim($_POST['phone']);
    $position=trim($_POST['position']);
    $address=trim($_POST['address']);
    $con=mysqli_connect("localhost","root","","nextech_portal_22rp04197");
    $insert=mysqli_query($con,"INSERT INTO 
    employees(employee_name,email,phone,position,address) 
    values('$name','$email','$phone','$position','$address')");
        if($insert){ 
    echo"<script>alert('Successfully!!');window.location='insert.php';</script>";
}

else{
    echo"<script>alert('Failed!');window.location='insert.php';</script>";
}
}
?>
</body></html>