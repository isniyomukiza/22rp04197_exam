<?php 
$con=mysqli_connect("localhost","root","","nextech_portal_22rp04197");
?>