<?php 
include("con.php");
?>
<?php 
$id=$_GET['id'];
$del=mysqli_query($con,"DELETE FROM employees WHERE id='$id'");
if($del)
{
    echo"<script> alert('Successfully Deleted');window.location='view.php';</script>";
}
?>