
<?php 
include("con.php");
?>
<?php 
if(isset($_GET['id'])){
$id=$_GET['id'];
        $select=mysqli_query($con,"SELECT * FROM employees where id='$id'");
        if(mysqli_num_rows($select)>0){
         $rows=mysqli_fetch_array($select);
            ?>
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>EMPLOYEE UPDATE</h2>
<form action="" method="POST">
    Employee_name:<br> <input type="text" name="employee_name" id="" value=" <?php echo $rows["employee_name"];?>" required><br>
    Email: <br><input type="email" name="email" value=" <?php echo $rows["email"];?>" required><br>
     Phone:<br> <input type="number" name="phone" value=" <?php echo$rows["phone"];?> " required><br>
    Position: <br><input type="text" name="position"  value=" <?php echo  $position=$rows["position"];?>" required><br>
  Address:<br> <input type="text" name="address"   value=" <?php echo $address=$rows["address"];?>"required><br>
<input type="submit" name="submit" value="Update">
</form>
            <?php 
              } }           
         if(isset($_POST['submit']))
{
     $name=$_POST['employee_name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $position=$_POST['position'];
    $address=$_POST['address'];   
    $query="UPDATE employees sET employee_name='$name',email='$email',position='$position',address='$address' WHERE id='$id'";
    $result=mysqli_query($con,$query);
         if($result)
         {
            echo"<script> alert('Successfully');window.location='view.php';</script>";
         }
         else{
            echo"<script> alert('Successfully');window.location='view.php';</script>";
         }
        }
        ?>